package model

/**
  * @author shubham
  * @implSpec
  * @since 2019-01-03
  */
case class User(age: Int, name: String)